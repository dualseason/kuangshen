package com.kuang.demo01;

/**
 * @author ：ltb
 * @date ：2020/7/14
 */
public class Host implements Rent {


    @Override
    public void rent() {
        System.out.println("房东要出租房子!");
    }
}
